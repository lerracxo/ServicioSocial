package com.ipn.esca.serviciosocial.dao;

public interface GenericDAO<T,Long> {
	

}
