package com.ipn.esca.serviciosocial.dao.impl;

import com.ipn.esca.serviciosocial.dao.GenericDAO;

public class GenericDAOBean<T,Long> implements GenericDAO<T,Long>{
	

}
