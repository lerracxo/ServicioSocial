package com.ipn.esca.serviciosocial.bs;

import javax.ejb.Local;

@Local
public interface ProfesorServiceLocal extends ProfesorIService {

	

}
