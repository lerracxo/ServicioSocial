package com.ipn.esca.serviciosocial.bs;

import javax.ejb.Remote;

@Remote
public interface ProfesorServiceRemote extends ProfesorIService {
}
